const White_List = [
    'http://ethersmasterpiece.com',
    'https://ethersmasterpiece.com',
    'https://www.ethersmasterpiece.com',
    'https://ethersmasterpiece.netlify.app'
]

module.exports = White_List
